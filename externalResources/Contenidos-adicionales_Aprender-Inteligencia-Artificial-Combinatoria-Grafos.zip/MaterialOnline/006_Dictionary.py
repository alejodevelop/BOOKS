dicc = {'Nombre' : 'Arnaldo', 'Edad' : 28}

print(dicc['Nombre'], dicc['Edad'])



dicc['Nombre'] = 'Gretica'
dicc['Edad'] = 27
print(dicc['Nombre'], dicc['Edad'])



print('Nombre' in dicc)