# ejemplo de ciclo while desarrollado en Python
i = 1
while i <= 5:
        print("Iteracion", i)
        i += 1

# ejemplo de ciclo for con range
print("Yo me llamo")
for i in range(1,6,2):
        print("Emilio el de las 5 (" + str(i) + ")")
