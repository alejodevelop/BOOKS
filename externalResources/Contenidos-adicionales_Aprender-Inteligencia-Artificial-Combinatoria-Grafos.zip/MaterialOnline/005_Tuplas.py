t = (1, 2, 3)

# ejemplo de algunas sentencias aplicables a tuplas
print (1 in t)
print (4 in t)
print (t[1:3])
