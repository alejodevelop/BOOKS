miLista = [1,2,3,4]
listTest = [5,6,7,8]

print (miLista + listTest)

print (miLista[2])



