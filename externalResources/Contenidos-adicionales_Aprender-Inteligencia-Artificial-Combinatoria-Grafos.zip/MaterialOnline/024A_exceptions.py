

# división por 0 con exception handling try/except

try:
    1 / 0
except ZeroDivisionError:
    print("No puedes dividir por 0!")

